﻿using ChessBoardModel;
using System;

namespace ChessBoardConsoleApp
{
    class Program
    {
        static Board myBoard = new Board(8);
        static void Main(string[] args)
        {
            //show the empty chess board
            printGrid(myBoard);

            //get the location of the chess piece
            Cell myLocation = setCurrentCell();

            //calculate and mark the cells where legal
            //moves are possible.

            Console.WriteLine("What piece do you want to move? (Knight, King, Queen, Bishop, Rook)");
            string piece = Console.ReadLine();
            myBoard.MarkNextLegalMoves(myLocation, piece);

            //show the chess board. Use . for an empty square, X for the piece location
            //and + for a possible legal move
            printGrid(myBoard);

            //wait for another return key to end the program
            Console.ReadLine();
        }
        static public void printGrid(Board myBoard)
        {
            for (int i = 0; i < myBoard.Size; i++)
            {
                for (int j = 0; j < myBoard.Size; j++)
                {
                    if (myBoard.theGrid[i, j].CurrentlyOccupied)
                    {
                        Console.Write("| X ");
                    }
                    else if (myBoard.theGrid[i, j].LegalNextMove)
                    {
                        Console.Write("| + ");
                    }
                    else
                    {
                        Console.Write("+---");
 
                    }
                    
                }     
                Console.Write("+");
                Console.WriteLine();
                Console.Write("|   ");
                Console.Write("|   ");
                Console.Write("|   ");
                Console.Write("|   ");
                Console.Write("|   ");
                Console.Write("|   ");
                Console.Write("|   ");
                Console.Write("|   ");
                Console.Write("|   ");
                Console.WriteLine();
                
            }Console.WriteLine("+---+---+---+---+---+---+---+---+");
            Console.WriteLine("===========================");
        }

        static public Cell setCurrentCell()
        {
            Console.Out.Write("Enter your current row number: ");
            string r = Console.ReadLine();
            int currentRow;
            if (int.TryParse(r, out currentRow))
            {
                currentRow = int.Parse(r);
            }
            else
            {
                Console.WriteLine("Not a number, try again please");
                Console.Out.Write("Enter your current row number: ");
                currentRow = int.Parse(Console.ReadLine());
            }
            Console.Out.Write("Enter your current column number: ");
            string c = Console.ReadLine();
            int currentCol;
            if (int.TryParse(r, out currentCol))
            {
                currentCol = int.Parse(r);
            }
            else
            {
                Console.Out.Write("Not a number, try again please");
                currentCol = int.Parse(Console.ReadLine());
            }
            myBoard.theGrid[currentRow, currentCol].CurrentlyOccupied = true;

            return myBoard.theGrid[currentRow, currentCol];
        }
    }
}
