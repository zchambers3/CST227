﻿using ChessBoardModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChessBoardGUIApp
{
    public partial class Form1 : Form
    {
        static public Board myBoard = new Board(8);
        public Button[,] btnGrid = new Button[myBoard.Size, myBoard.Size];
        public Form1()
        {
            InitializeComponent();
            populateGrid();
        }
        public void populateGrid()
        {
            //fill the panel1 control with buttons
            int buttonSize = panel1.Width / myBoard.Size;
            //set the grid to be square.
            panel1.Height = panel1.Width;

            for (int r = 0; r < myBoard.Size; r++)
            {
                for (int c = 0; c < myBoard.Size; c++)
                {
                    btnGrid[r, c] = new Button();
                    //make each button square
                    btnGrid[r, c].Width = buttonSize;
                    btnGrid[r, c].Height = buttonSize;

                    btnGrid[r, c].Click += Grid_Button_Click; //Add the same click event to each button.
                    panel1.Controls.Add(btnGrid[r, c]); //place the button on the Panel
                    btnGrid[r, c].Location = new Point(buttonSize * r, buttonSize * c); //position it in x,y

                    btnGrid[r, c].Text = r + "|" + c;
                    btnGrid[r, c].Tag = new Point(r, c);
                }
            }


        }

        private void Grid_Button_Click(object sender, EventArgs e)
        {
            //get the row and column number of the button just clicked.
            Button clickedButton = (Button)sender;
            Point location = (Point)clickedButton.Tag;
            int x = location.X;
            int y = location.Y;

            //run a help function to label all legal moves for this place.
            Cell currentCell = myBoard.theGrid[x, y];
            myBoard.MarkNextLegalMoves(currentCell, comboBox1.Text);
           
            //reset the background color of all buttons to the default color.
            for (int i = 0; i < myBoard.Size; i++)
            {
                for (int j = 0; j < myBoard.Size; j++)
                {

                    btnGrid[i, j].BackColor = default(Color);
                }
            }
            //set the background color of the clicked button to something different
            (sender as Button).BackColor = Color.Cornsilk;

            for (int i = 0; i < myBoard.Size; i++)
            {
                for (int j = 0; j < myBoard.Size; j++)
                {
                    btnGrid[i, j].Text = "";
                    if(myBoard.theGrid[i, j].LegalNextMove)
                        btnGrid[i, j].Text = "Legal";
                    if (myBoard.theGrid[i, j].CurrentlyOccupied)
                        btnGrid[i, j].Text = comboBox1.Text;
                    myBoard.theGrid[i, j].CurrentlyOccupied = false;
                }
            }
        }
        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
