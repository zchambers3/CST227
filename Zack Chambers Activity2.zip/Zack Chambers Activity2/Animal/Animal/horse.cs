﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Animal
{
    class horse : Animal
    {
        public void RideMe()
        {
            Console.WriteLine("Lets go for a ride around town.");
        }
        public void Greet()
        {
            Console.WriteLine("Nhhheee");

        }
    }
}
