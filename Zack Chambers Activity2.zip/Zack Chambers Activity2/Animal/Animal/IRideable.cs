﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Animal
{
    interface IRideable
    {
        void RideMe();
    }
}
