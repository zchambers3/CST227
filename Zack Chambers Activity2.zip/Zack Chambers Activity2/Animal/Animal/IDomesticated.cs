﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Animal
{
    interface IDomesticated
    {
        void TouchMe();
        void FeedMe();

    }
}
