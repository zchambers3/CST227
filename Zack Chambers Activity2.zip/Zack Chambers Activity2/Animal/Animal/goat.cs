﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Animal
{
    class goat : Animal
    {
        public void MilkMe()
        {
            Console.WriteLine("Time to fill the bucket full of milk.");
        }
        public void Greet()
        {
            Console.WriteLine("bhaaaaa");

        }
    }
}
