﻿using System;

namespace Animal
{
    class Program
    {
        static void Main(string[] args)
        {
            //Animal beast = new Animal(true, 100);

            //beast.Greet();
            //beast.Talk();
            //beast.Sing();

            //Console.WriteLine(beast.ToString());

            Dog fido = new Dog(false, 25);

            fido.Greet();
            fido.Talk();
            fido.Sing();
            fido.Fetch("stick");

            fido.TouchMe();
            fido.FeedMe();

            Console.WriteLine(fido.ToString());

            Robin red = new Robin();
            red.Talk();
            red.Sing();
            cow Cow = new cow();
            Cow.Sing();
            Cow.MilkMe();
            Cow.MakeBread();
            goat Goat = new goat();
            Goat.MilkMe();
            Goat.Talk();
            Goat.Greet();
            horse Horse = new horse();
            Horse.Greet();
            Horse.RideMe();



            Console.ReadLine();
        }
    }
}
